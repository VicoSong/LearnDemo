/*
Navicat MySQL Data Transfer

Source Server         : 172.16.171.250
Source Server Version : 50619
Source Host           : 172.16.171.250:3306
Source Database       : aws

Target Server Type    : MYSQL
Target Server Version : 50619
File Encoding         : 65001

Date: 2015-12-26 09:00:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for b_accitem_setup
-- ----------------------------
DROP TABLE IF EXISTS `b_accitem_setup`;
CREATE TABLE `b_accitem_setup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accitem_code` varchar(20) NOT NULL COMMENT '会计科目编码',
  `accitem_name` varchar(30) NOT NULL COMMENT '会计科目名称',
  `remark` varchar(100) DEFAULT NULL,
  `creator` varchar(20) DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_user` varchar(20) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`,`accitem_code`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_accitem_setup
-- ----------------------------
INSERT INTO `b_accitem_setup` VALUES ('9', '8500100100', '办公费', '办公用品', 'weikang.song', '2015-12-14 15:43:48', 'weikang.song', '2015-12-14 15:48:26');
INSERT INTO `b_accitem_setup` VALUES ('12', '8300100304', '备品备件费3', '机器设备的备品备件', 'cfx', '2015-12-09 20:40:14', 'weikang.song', '2015-12-15 22:04:21');
INSERT INTO `b_accitem_setup` VALUES ('13', '8300100200', '劳动费', '爱迪生', 'weikang.song', '2015-12-23 14:41:42', 'weikang.song', '2015-12-23 14:42:00');
INSERT INTO `b_accitem_setup` VALUES ('14', '8300100300', '消耗品', '', 'weikang.song', '2015-12-23 14:44:06', null, null);
INSERT INTO `b_accitem_setup` VALUES ('18', '789', '返回', '下方', 'weikang.song', '2015-12-25 10:16:40', null, null);
INSERT INTO `b_accitem_setup` VALUES ('19', '785', 'kmn', 'bk', 'weikang.song', '2015-12-25 10:44:02', null, null);

-- ----------------------------
-- Table structure for b_alert_mail
-- ----------------------------
DROP TABLE IF EXISTS `b_alert_mail`;
CREATE TABLE `b_alert_mail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(20) NOT NULL,
  `MAILUSER` varchar(50) NOT NULL,
  `MAILTYPE` varchar(10) NOT NULL DEFAULT 'TO',
  `MAILDEPT` varchar(20) DEFAULT NULL,
  `FACTORY_ID` varchar(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_alert_mail
-- ----------------------------
INSERT INTO `b_alert_mail` VALUES ('1', '宋维康', 'weikang.song@feixun.com.cn', 'CC', 'AD', '2100');
INSERT INTO `b_alert_mail` VALUES ('2', '崔亚伟', 'yawei.cui@feixun.com.cn', 'TO', 'AD', '2100');

-- ----------------------------
-- Table structure for b_aws_seq
-- ----------------------------
DROP TABLE IF EXISTS `b_aws_seq`;
CREATE TABLE `b_aws_seq` (
  `LOOKUP_TYPE` varchar(20) NOT NULL,
  `PARAMETER1` varchar(80) DEFAULT NULL,
  `PARAMETER2` varchar(80) DEFAULT NULL,
  `SEQ` int(11) NOT NULL DEFAULT '0',
  `CREATETIME` datetime DEFAULT NULL,
  `CREATEUSER` varchar(30) DEFAULT NULL,
  `UPDATETIME` datetime DEFAULT NULL,
  `UPDATEUSER` varchar(30) DEFAULT NULL,
  KEY `b_mes_seq_inx1` (`LOOKUP_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_aws_seq
-- ----------------------------
INSERT INTO `b_aws_seq` VALUES ('FIRSTLEVEL', '2', null, '1', '2015-12-18 10:01:16', null, null, null);
INSERT INTO `b_aws_seq` VALUES ('SECONDLEVEL', '5', null, '1', '2015-12-18 10:15:07', 'kang.chen', null, null);
INSERT INTO `b_aws_seq` VALUES ('SPECLEVEL', '1', null, '6', '2015-12-18 15:48:24', 'kang.chen', null, null);
INSERT INTO `b_aws_seq` VALUES ('SPECLEVEL', 'CATEGORY_NAME', null, '1', '2015-12-18 16:50:48', 'kang.chen', null, null);
INSERT INTO `b_aws_seq` VALUES ('SPECLEVEL', '静电衣XL2', null, '4', '2015-12-18 16:59:02', 'kang.chen', null, null);
INSERT INTO `b_aws_seq` VALUES ('CONSUMABLES', 'dateStr', null, '80', '2015-12-20 23:45:27', 'weikang.song', null, null);
INSERT INTO `b_aws_seq` VALUES ('FIRSTLEVEL', '123', null, '1', '2015-12-24 09:35:15', 'kang.chen', null, null);
INSERT INTO `b_aws_seq` VALUES ('SECONDLEVEL', '2', null, '1', '2015-12-24 09:36:06', 'kang.chen', null, null);
INSERT INTO `b_aws_seq` VALUES ('SPECLEVEL', '发的', null, '1', '2015-12-24 09:36:46', 'kang.chen', null, null);
INSERT INTO `b_aws_seq` VALUES ('LY', 'LY', null, '3', '2015-12-25 16:33:43', 'yechun.ning', null, null);

-- ----------------------------
-- Table structure for b_category_setup
-- ----------------------------
DROP TABLE IF EXISTS `b_category_setup`;
CREATE TABLE `b_category_setup` (
  `CATEGORY_ID` varchar(40) NOT NULL,
  `CATEGORY_NAME` varchar(50) NOT NULL,
  `PARENT_ID` varchar(20) NOT NULL,
  `CATEGORY_TYPE` varchar(2) NOT NULL,
  `ACCITEM_CODE` varchar(20) NOT NULL,
  `CREATEUSER` varchar(30) NOT NULL,
  `CREATETIME` datetime NOT NULL,
  `UPDATEUSER` varchar(30) DEFAULT NULL,
  `UPDATETIME` datetime DEFAULT NULL,
  PRIMARY KEY (`CATEGORY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_category_setup
-- ----------------------------
INSERT INTO `b_category_setup` VALUES ('100020', '25', '2', 'M', '8300100300', 'kang.chen', '2015-12-17 15:50:57', 'kang.chen', '2015-12-21 15:25:54');
INSERT INTO `b_category_setup` VALUES ('100021', '3', '2', 'M', '8300100300', 'kang.chen', '2015-12-17 15:51:14', null, null);
INSERT INTO `b_category_setup` VALUES ('100022', '22', '2', 'M', '8300100300', 'kang.chen', '2015-12-17 15:51:26', null, null);
INSERT INTO `b_category_setup` VALUES ('13', 'M', 'NA', 'S', 'NA', 'FX007459', '2015-12-16 15:35:22', null, null);
INSERT INTO `b_category_setup` VALUES ('14', 'XL', '3', 'S', 'NA', 'FX007459', '2015-12-16 15:35:58', null, null);
INSERT INTO `b_category_setup` VALUES ('15', '办公用品5', 'NA', 'B', '8300100304', 'FX007459', '2015-12-17 15:26:38', 'kang.chen', '2015-12-24 09:35:07');
INSERT INTO `b_category_setup` VALUES ('16', '笔', '15', 'M', '8300100304', 'FX007459', '2015-12-17 15:28:45', null, null);
INSERT INTO `b_category_setup` VALUES ('17', 'notebook', '15', 'M', '830010304', 'FX007459', '2015-12-17 15:30:13', null, null);
INSERT INTO `b_category_setup` VALUES ('18', '0.5mm', '16', 'S', '1233', 'FX007459', '2015-12-17 15:35:39', null, null);
INSERT INTO `b_category_setup` VALUES ('19', '0.7mm', '16', 'S', '3654', 'FX007459', '2015-12-17 15:36:29', null, null);
INSERT INTO `b_category_setup` VALUES ('2', '办公用品', 'NA', 'B', '8300100300', 'kang.chen', '2015-12-15 14:32:58', 'kang.chen', '2015-12-16 09:38:01');
INSERT INTO `b_category_setup` VALUES ('20', '劳保用品', 'NA', 'B', '987', 'FX007459', '2015-12-17 15:39:53', null, null);
INSERT INTO `b_category_setup` VALUES ('21', '衣服', '20', 'M', '789', 'FX007459', '2015-12-17 15:41:06', null, null);
INSERT INTO `b_category_setup` VALUES ('22', 'XXL', '21', 'S', '987', 'FX007459', '2015-12-17 15:43:30', null, null);
INSERT INTO `b_category_setup` VALUES ('23', 'XXXL', '21', 'S', '987', 'FX007459', '2015-12-17 15:44:12', null, null);
INSERT INTO `b_category_setup` VALUES ('24', 'XXL号号', '21', 'S', '987', 'fx007459', '2015-12-17 15:44:46', null, null);
INSERT INTO `b_category_setup` VALUES ('5', 'test2', 'NA', 'C', '8300100305', 'kang.chen', '2015-12-15 15:39:32', 'kang.chen', '2015-12-15 15:40:06');
INSERT INTO `b_category_setup` VALUES ('6', 'f', 'NA', 'C', '8300100403', 'kang.chen', '2015-12-15 16:43:28', 'kang.chen', '2015-12-16 08:34:48');
INSERT INTO `b_category_setup` VALUES ('7', '手机', 'NA', 'B', '8300100304', 'FX007459', '2015-12-15 19:50:15', null, null);
INSERT INTO `b_category_setup` VALUES ('8', 'E', 'NA', 'B', '8300100302', 'kang.chen', '2015-12-16 09:06:03', null, null);
INSERT INTO `b_category_setup` VALUES ('AWS20151218001', '21', 'NA', 'B', '8300100300', 'kang.chen', '2015-12-18 09:53:48', 'kang.chen', '2015-12-21 15:10:07');
INSERT INTO `b_category_setup` VALUES ('B20151217164027', '衣服', 'NA', 'B', '8300100300', 'kang.chen', '2015-12-17 16:33:00', null, null);
INSERT INTO `b_category_setup` VALUES ('M20151217165206', '5', '15', 'M', '8300100304', 'kang.chen', '2015-12-17 16:44:39', 'kang.chen', '2015-12-21 15:20:27');
INSERT INTO `b_category_setup` VALUES ('M20151218001', '静电衣', 'B20151217164027', 'M', '8300100300', 'kang.chen', '2015-12-18 10:07:39', null, null);
INSERT INTO `b_category_setup` VALUES ('M20151218002', '防潮衣', 'B20151217164027', 'M', '8300100400', 'kang.chen', '2015-12-18 10:07:39', '', '2015-12-18 10:55:08');
INSERT INTO `b_category_setup` VALUES ('S20151218001', '静电衣', '100020', 'S', '8300100300', 'kang.chen', '2015-12-18 10:07:39', 'kang.chen', '2015-12-24 09:36:39');
INSERT INTO `b_category_setup` VALUES ('S20151218002', '静电衣XLL', 'M20151218001', 'S', '8300100300', 'kang.chen', '2015-12-18 10:07:39', '', '2015-12-18 10:41:37');
INSERT INTO `b_category_setup` VALUES ('S20151218004', '静电衣XL2', 'M20151218001', 'S', '8300100300', 'kang.chen', '2015-12-18 18:42:05', null, null);

-- ----------------------------
-- Table structure for b_consumables_info
-- ----------------------------
DROP TABLE IF EXISTS `b_consumables_info`;
CREATE TABLE `b_consumables_info` (
  `CONSUMABLES_ID` varchar(40) NOT NULL COMMENT '耗材ID',
  `CONSUMABLES_NAME` varchar(50) DEFAULT NULL COMMENT '耗材名称',
  `FACTORY_ID` varchar(10) DEFAULT NULL COMMENT '工厂代码',
  `FIRST_LEVEL_ID` varchar(40) DEFAULT NULL COMMENT '一级分类ID',
  `SECOND_LEVEL_ID` varchar(40) DEFAULT NULL COMMENT '二级分类ID',
  `SPEC_ID` varchar(40) DEFAULT NULL COMMENT '规格ID',
  `MUNIT` varchar(10) DEFAULT NULL COMMENT '耗材单位',
  `AVGPRICE` decimal(10,2) DEFAULT NULL COMMENT '平均价',
  `REMARK` varchar(255) DEFAULT NULL COMMENT '备注',
  `IMAGE_PATH` varchar(150) DEFAULT NULL COMMENT '图片路径',
  `CREATEUSER` varchar(20) DEFAULT NULL COMMENT '创建人',
  `CREATETIME` datetime DEFAULT NULL COMMENT '创建时间',
  `UPDATEUSER` varchar(20) DEFAULT NULL COMMENT '更新人',
  `UPDATETIME` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`CONSUMABLES_ID`),
  KEY `idx_consumables_name` (`CONSUMABLES_NAME`) USING BTREE,
  KEY `idx_factory_id` (`FACTORY_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_consumables_info
-- ----------------------------
INSERT INTO `b_consumables_info` VALUES ('151225000080', '圆珠笔', '1100', '15', '16', '18', '支', null, '晨光牌', 'N:\\img\\u=1518964894,4010821592&fm=116&gp=0.jpg', 'weikang.song', '2015-12-25 14:02:24', null, null);

-- ----------------------------
-- Table structure for b_mes_departments
-- ----------------------------
DROP TABLE IF EXISTS `b_mes_departments`;
CREATE TABLE `b_mes_departments` (
  `DEPT_ID` varchar(20) NOT NULL,
  `DEPT_NAME` varchar(20) DEFAULT NULL,
  `FACTORY_ID` varchar(10) DEFAULT NULL,
  `DEPT_FIRST` varchar(20) DEFAULT NULL,
  `DEPT_SECOND` varchar(20) DEFAULT NULL,
  `DEPT_THIRD` varchar(20) DEFAULT NULL,
  `CREATEUSER` varchar(20) DEFAULT NULL,
  `CREATETIME` datetime DEFAULT NULL,
  PRIMARY KEY (`DEPT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_mes_departments
-- ----------------------------
INSERT INTO `b_mes_departments` VALUES ('101', '供应链平台', '2100', null, null, null, null, null);
INSERT INTO `b_mes_departments` VALUES ('102', '上海万德凯(7#基地)', '2100', '101', '', '', 'hxl', '2015-05-04 16:24:45');
INSERT INTO `b_mes_departments` VALUES ('103', 'SMT制造部', '2100', '101', '102', '', 'hxl', '2015-05-04 16:29:15');
INSERT INTO `b_mes_departments` VALUES ('104', '装配制造部', '2100', '101', '102', '', 'hxl', '2015-05-04 16:30:48');
INSERT INTO `b_mes_departments` VALUES ('105', '产品技术部', '2100', '101', '102', '', 'hxl', '2015-05-04 16:44:09');
INSERT INTO `b_mes_departments` VALUES ('106', '生产技术部', '2100', '101', '102', '', 'hxl', '2015-05-04 16:58:25');
INSERT INTO `b_mes_departments` VALUES ('107', '生产品质管理部', null, '101', '102', '', 'hxl', '2015-05-04 16:59:02');
INSERT INTO `b_mes_departments` VALUES ('108', '生产计划部', null, '101', '102', '', 'hxl', '2015-05-04 16:59:59');
INSERT INTO `b_mes_departments` VALUES ('109', '仓储部', null, '101', '102', '', 'hxl', '2015-05-04 17:00:57');
INSERT INTO `b_mes_departments` VALUES ('110', '行政部', null, '101', '102', '', 'hxl', '2015-05-05 09:18:41');
INSERT INTO `b_mes_departments` VALUES ('111', '人力资源部', null, '101', '102', '', 'hxl', '2015-05-05 09:19:00');
INSERT INTO `b_mes_departments` VALUES ('112', '财务部', '1100', '101', '102', '', 'hxl', '2015-05-05 09:19:29');
INSERT INTO `b_mes_departments` VALUES ('113', '生产一科', null, '101', '102', '103', 'hxl', '2015-05-05 09:20:27');
INSERT INTO `b_mes_departments` VALUES ('114', '生产二科', '1100', '101', '102', '103', 'hxl', '2015-05-05 09:21:31');
INSERT INTO `b_mes_departments` VALUES ('115', 'SMT线边科', null, '101', '102', '103', 'hxl', '2015-05-05 09:22:17');
INSERT INTO `b_mes_departments` VALUES ('116', 'PCBA维修科', null, '101', '102', '103', 'hxl', '2015-05-05 09:22:49');
INSERT INTO `b_mes_departments` VALUES ('117', '生产一科2', '1100', '101', '102', '104', 'hxl', '2015-05-05 10:48:51');
INSERT INTO `b_mes_departments` VALUES ('118', '生产二科2', null, '101', '102', '104', 'hxl', '2015-05-05 10:49:07');
INSERT INTO `b_mes_departments` VALUES ('119', '维修科', null, '101', '102', '104', 'hxl', '2015-05-05 10:49:32');
INSERT INTO `b_mes_departments` VALUES ('120', '装配预加工科', '1100', '101', '102', '104', 'hxl', '2015-05-05 10:50:03');
INSERT INTO `b_mes_departments` VALUES ('121', '产品测试科', null, '101', '102', '105', 'hxl', '2015-05-05 10:50:40');
INSERT INTO `b_mes_departments` VALUES ('122', '产品工程科', null, '101', '102', '105', 'hxl', '2015-05-05 10:51:05');
INSERT INTO `b_mes_departments` VALUES ('123', '产品项目科', '1100', '101', '102', '105', 'hxl', '2015-05-05 10:51:30');
INSERT INTO `b_mes_departments` VALUES ('124', '制程科', null, '101', '102', '106', 'hxl', '2015-05-05 10:52:00');
INSERT INTO `b_mes_departments` VALUES ('125', '设备科', null, '101', '102', '106', 'hxl', '2015-05-05 10:52:49');
INSERT INTO `b_mes_departments` VALUES ('126', '工业工程科', '1100', '101', '102', '106', 'hxl', '2015-05-05 10:54:10');
INSERT INTO `b_mes_departments` VALUES ('127', '品质保证科', null, '101', '102', '107', 'hxl', '2015-05-05 10:54:28');
INSERT INTO `b_mes_departments` VALUES ('128', '品质工程科', null, '101', '102', '107', 'hxl', '2015-05-05 10:54:48');
INSERT INTO `b_mes_departments` VALUES ('129', '品质检验科', '1100', '101', '102', '107', 'hxl', '2015-05-05 10:55:06');
INSERT INTO `b_mes_departments` VALUES ('130', '库存管理科', null, '101', '102', '109', 'hxl', '2015-05-05 10:56:43');
INSERT INTO `b_mes_departments` VALUES ('131', '财务管理科', null, '101', '102', '109', 'hxl', '2015-05-05 10:57:01');
INSERT INTO `b_mes_departments` VALUES ('132', '成品管理科', null, '101', '102', '109', 'hxl', '2015-05-05 10:57:30');
INSERT INTO `b_mes_departments` VALUES ('133', '餐饮管理科', '1100', '101', '102', '110', 'hxl', '2015-05-05 10:58:09');
INSERT INTO `b_mes_departments` VALUES ('134', '环境安全科', null, '101', '102', '110', 'hxl', '2015-05-05 10:58:27');
INSERT INTO `b_mes_departments` VALUES ('135', '工程维修科', '1100', '101', '102', '110', 'hxl', '2015-05-05 11:00:41');
INSERT INTO `b_mes_departments` VALUES ('136', '总务科', null, '101', '102', '110', 'hxl', '2015-05-05 11:00:58');
INSERT INTO `b_mes_departments` VALUES ('137', '维修科', null, '101', '102', '110', 'hxl', '2015-05-05 11:01:10');
INSERT INTO `b_mes_departments` VALUES ('201', '信息平台', '1100', '', '', '', 'hxl', '2015-05-06 10:12:19');
INSERT INTO `b_mes_departments` VALUES ('202', '制造执行系统部', '1100', '201', '', '', 'hxl', '2015-05-06 10:12:56');
INSERT INTO `b_mes_departments` VALUES ('203', '应用系统部', '1100', '201', '', '', 'hxl', '2015-05-06 10:59:17');
INSERT INTO `b_mes_departments` VALUES ('204', '治具加工科', null, '101', '102', '103', 'hxl', '2015-05-22 09:44:16');

-- ----------------------------
-- Table structure for b_mes_factory
-- ----------------------------
DROP TABLE IF EXISTS `b_mes_factory`;
CREATE TABLE `b_mes_factory` (
  `FACTORY_ID` varchar(10) NOT NULL COMMENT '工厂代码',
  `FACTORY_NAME` varchar(50) NOT NULL COMMENT '工厂名称',
  `LOCATION` varchar(100) DEFAULT NULL COMMENT '地址',
  `CREATEUSER` varchar(30) DEFAULT NULL,
  `CREATETIME` datetime DEFAULT NULL,
  `UPDATEUSER` varchar(30) DEFAULT NULL,
  `UPDATETIME` datetime DEFAULT NULL,
  PRIMARY KEY (`FACTORY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_mes_factory
-- ----------------------------
INSERT INTO `b_mes_factory` VALUES ('1100', '斐讯', '中国上海松江区 文吉路99号', 'yawei.cui', '2015-12-10 16:38:51', null, null);
INSERT INTO `b_mes_factory` VALUES ('2100', '万德凯', '中国上海松江区 松蒸公路', 'yawei.cui', '2015-12-10 16:39:28', null, null);

-- ----------------------------
-- Table structure for b_mes_groups
-- ----------------------------
DROP TABLE IF EXISTS `b_mes_groups`;
CREATE TABLE `b_mes_groups` (
  `GROUP_ID` varchar(20) NOT NULL,
  `GROUP_NAME` varchar(20) DEFAULT NULL,
  `CREATETIME` datetime DEFAULT NULL,
  `CREATEUSER` varchar(20) DEFAULT NULL,
  `UPDATEUSER` varchar(20) DEFAULT NULL,
  `UPDATETIME` datetime DEFAULT NULL,
  PRIMARY KEY (`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_mes_groups
-- ----------------------------
INSERT INTO `b_mes_groups` VALUES ('admin', '管理员', '2015-01-19 16:35:06', 'yawei.cui', '', '2015-01-19 16:35:06');

-- ----------------------------
-- Table structure for b_mes_group_page
-- ----------------------------
DROP TABLE IF EXISTS `b_mes_group_page`;
CREATE TABLE `b_mes_group_page` (
  `GROUP_ID` varchar(20) NOT NULL,
  `PAGE_ID` varchar(40) NOT NULL,
  `CREATEUSER` varchar(20) DEFAULT NULL,
  `CREATETIME` datetime DEFAULT NULL,
  PRIMARY KEY (`GROUP_ID`,`PAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_mes_group_page
-- ----------------------------
INSERT INTO `b_mes_group_page` VALUES ('admin', '', '', '2015-12-14 15:35:06');

-- ----------------------------
-- Table structure for b_mes_mainmenu
-- ----------------------------
DROP TABLE IF EXISTS `b_mes_mainmenu`;
CREATE TABLE `b_mes_mainmenu` (
  `MAIN_MENUID` varchar(20) NOT NULL,
  `MAIN_MENUNAME` varchar(20) DEFAULT NULL,
  `CREATEUSER` varchar(20) DEFAULT NULL,
  `CREATETIME` datetime DEFAULT NULL,
  `UPDATEUSER` varchar(20) DEFAULT NULL,
  `UPDATETIME` datetime DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  PRIMARY KEY (`MAIN_MENUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_mes_mainmenu
-- ----------------------------
INSERT INTO `b_mes_mainmenu` VALUES ('Base_setup', '基础设定', 'yawei.cui', '2015-12-11 20:40:02', null, null, '2');
INSERT INTO `b_mes_mainmenu` VALUES ('Consumables_request', '耗材领用', 'yawei.cui', '2015-12-11 20:40:02', null, null, '4');
INSERT INTO `b_mes_mainmenu` VALUES ('Inventory_management', '库存管理', 'yawei.cui', '2015-12-11 20:40:02', null, null, '3');
INSERT INTO `b_mes_mainmenu` VALUES ('Report_query', '报表查询', 'yawei.cui', '2015-12-11 20:40:02', null, null, '5');
INSERT INTO `b_mes_mainmenu` VALUES ('System_setup', '系统设置', 'yawei.cui', '2015-12-11 20:39:39', null, null, '1');

-- ----------------------------
-- Table structure for b_mes_pages
-- ----------------------------
DROP TABLE IF EXISTS `b_mes_pages`;
CREATE TABLE `b_mes_pages` (
  `PAGE_ID` varchar(50) NOT NULL,
  `PAGE_NAME` varchar(20) DEFAULT NULL,
  `DESCRIPTION` varchar(20) DEFAULT NULL,
  `PAGE_TYPE` varchar(20) DEFAULT NULL,
  `PAGE_URL` varchar(200) DEFAULT NULL,
  `REPORT_ID` varchar(40) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `SUB_MENUID` varchar(20) DEFAULT NULL,
  `CREATEUSER` varchar(20) DEFAULT NULL,
  `CREATETIME` datetime DEFAULT NULL,
  `UPDATEUSER` varchar(20) DEFAULT NULL,
  `UPDATETIME` datetime DEFAULT NULL,
  PRIMARY KEY (`PAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_mes_pages
-- ----------------------------
INSERT INTO `b_mes_pages` VALUES ('accountitem', '会计科目设定', '用于设定会计科目', '', '', '', '37', 'Base_Sub_finance', 'weikang.song', '2015-12-14 12:33:15', null, null);
INSERT INTO `b_mes_pages` VALUES ('alertmail', '报警邮件设定', '报警邮件设定', '', '', '', '48', 'Base_Sub_admin', 'yawei.cui', '2015-12-18 13:50:16', null, null);
INSERT INTO `b_mes_pages` VALUES ('consumablesinfosetup', '耗材基本资料设定', '用于设定耗材基本资料', '', '', '', '45', 'Base_Sub_admin', 'weikang.song', '2015-12-17 11:10:13', null, null);
INSERT INTO `b_mes_pages` VALUES ('department', '部门管理', '部门管理', '', '', '', '6', 'System_Sub_privsetup', 'hxl', '2015-04-23 10:11:45', 'hxl', '2015-04-23 10:12:08');
INSERT INTO `b_mes_pages` VALUES ('factorysetup', '工厂代码设定', '工厂代码设定', '', '', '', '36', 'System_Sub_privsetup', 'yawei.cui', '2015-12-14 09:34:35', null, null);
INSERT INTO `b_mes_pages` VALUES ('finance_costrecord', '出入库成本明细查询', '出入库成本明细查询', '', '', '', '53', 'Report_Sub_finance', 'yechun.ning', '2015-12-25 09:38:02', null, null);
INSERT INTO `b_mes_pages` VALUES ('func_inventory_po', '采购订单入库', '采购订单入库', '', '', '', '42', 'Inventory_Sub_in', 'ccl', '2015-12-15 13:05:41', null, null);
INSERT INTO `b_mes_pages` VALUES ('InOutRecord', '出入库记录查询报表', '', '', '', '', '49', 'Report_Sub_admin', 'kang.chen', '2015-12-22 10:53:55', 'kang.chen', '2015-12-22 10:54:28');
INSERT INTO `b_mes_pages` VALUES ('inventory_deliver', '发货', '发货', '', '', '', '44', 'Inventory_Sub_out', 'yechun.ning', '2015-12-16 09:53:51', null, null);
INSERT INTO `b_mes_pages` VALUES ('inventory_quantity', '总库存及部门库存查询', '总库存及部门库存查询', '', '', '', '50', 'Report_Sub_admin', 'yechun.ning', '2015-12-22 15:19:14', null, null);
INSERT INTO `b_mes_pages` VALUES ('inventory_quantity_record', '发货历史查询', '发货历史查询', '', '', '', '51', 'Report_Sub_request', 'yechun.ning', '2015-12-23 11:06:34', null, null);
INSERT INTO `b_mes_pages` VALUES ('inventory_request', '领用申请', '领用申请', '', '', '', '52', 'Consum_Sub_request', 'yechun.ning', '2015-12-23 15:27:10', null, null);
INSERT INTO `b_mes_pages` VALUES ('mainmenu', '主菜单管理', '主菜单管理', null, null, null, '1', 'System_Sub_privsetup', 'zzk', '2015-03-02 13:47:05', null, null);
INSERT INTO `b_mes_pages` VALUES ('OneKindSetup', '耗材一级分类设定', '耗材一级分类设定', '', '', '', '41', 'Base_Sub_admin', 'kang.chen', '2015-12-14 15:34:36', null, null);
INSERT INTO `b_mes_pages` VALUES ('page', '页面管理', '页面管理', null, null, null, '4', 'System_Sub_privsetup', 'zzk', '2015-03-16 09:00:13', null, null);
INSERT INTO `b_mes_pages` VALUES ('planlist', '计划报表', '计划报表', null, null, null, '35', null, null, null, null, null);
INSERT INTO `b_mes_pages` VALUES ('rolemanagement', '角色管理', '角色管理', null, null, null, '3', 'System_Sub_privsetup', 'zzk', '2015-03-02 16:24:53', null, null);
INSERT INTO `b_mes_pages` VALUES ('rpt_inventory_po', '采购订单报表', '采购订单报表', '', '', '', '40', 'Inventory_Sub_in', 'ccl', '2015-12-14 14:54:24', null, null);
INSERT INTO `b_mes_pages` VALUES ('rpt_inventory_wh', '采购库存报表', '采购库存报表', '', '', '', '46', 'Inventory_Sub_in', 'ccl', '2015-12-18 10:10:53', null, null);
INSERT INTO `b_mes_pages` VALUES ('safestock', '安全库存设定', '用于设定安全库存', '', '', '', '38', 'Base_Sub_admin', 'weikang.song', '2015-12-14 12:35:21', null, null);
INSERT INTO `b_mes_pages` VALUES ('SpecificationsSetup', '耗材规格设定', '', '', '', '', '47', 'Base_Sub_admin', 'kang.chen', '2015-12-18 11:05:07', null, null);
INSERT INTO `b_mes_pages` VALUES ('submenu', '子菜单管理', '子菜单管理', null, null, null, '2', 'System_Sub_privsetup', 'zzk', '2015-03-16 08:58:45', null, null);
INSERT INTO `b_mes_pages` VALUES ('twoKindSetup', '耗材二级分类设定', '', '', '', '', '43', 'Base_Sub_admin', 'kang.chen', '2015-12-16 08:59:32', 'kang.chen', '2015-12-18 11:08:57');
INSERT INTO `b_mes_pages` VALUES ('user', '用户管理', '用户管理', null, null, null, '5', 'System_Sub_privsetup', 'zzk', '2015-03-16 09:00:15', null, null);

-- ----------------------------
-- Table structure for b_mes_submenu
-- ----------------------------
DROP TABLE IF EXISTS `b_mes_submenu`;
CREATE TABLE `b_mes_submenu` (
  `SUB_MENUID` varchar(20) NOT NULL,
  `SUB_MENUNAME` varchar(20) DEFAULT NULL,
  `SEQ` int(11) DEFAULT NULL,
  `MAIN_MENUID` varchar(20) DEFAULT NULL,
  `SUB_URL` varchar(200) DEFAULT NULL,
  `CREATEUSER` varchar(20) DEFAULT NULL,
  `CREATETIME` datetime DEFAULT NULL,
  `UPDATEUSER` varchar(20) DEFAULT NULL,
  `UPDATETIME` datetime DEFAULT NULL,
  PRIMARY KEY (`SUB_MENUID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_mes_submenu
-- ----------------------------
INSERT INTO `b_mes_submenu` VALUES ('Base_Sub_admin', '行政设定', '2', 'Base_setup', '', 'yawei.cui', '2015-01-19 20:41:13', null, null);
INSERT INTO `b_mes_submenu` VALUES ('Base_Sub_finance', '财务设定', '3', 'Base_setup', null, 'yawei.cui', '2015-01-19 20:41:13', null, null);
INSERT INTO `b_mes_submenu` VALUES ('Consum_Sub_request', '领用申请', '6', 'Consumables_request', '', 'yawei.cui', '2015-01-19 20:41:13', 'zhengkai.zhai', '2015-06-29 10:53:00');
INSERT INTO `b_mes_submenu` VALUES ('Inventory_Sub_in', '入库管理', '4', 'Inventory_management', null, 'yawei.cui', '2015-01-19 20:41:13', null, null);
INSERT INTO `b_mes_submenu` VALUES ('Inventory_Sub_out', '出库管理', '5', 'Inventory_management', null, 'yawei.cui', '2015-01-19 20:41:13', null, null);
INSERT INTO `b_mes_submenu` VALUES ('Report_Sub_admin', '行政报表', '7', 'Report_query', '', 'yawei.cui', '2015-01-19 20:41:13', 'hxl', '2015-05-06 13:57:40');
INSERT INTO `b_mes_submenu` VALUES ('Report_Sub_finance', '财务报表', '8', 'Report_query', null, 'yawei.cui', '2015-01-19 20:41:13', null, null);
INSERT INTO `b_mes_submenu` VALUES ('Report_Sub_request', '领用报表', '9', 'Report_query', null, 'yawei.cui', '2015-01-19 20:41:13', null, null);
INSERT INTO `b_mes_submenu` VALUES ('System_Sub_privsetup', '权限设定', '1', 'System_setup', '', 'yawei.cui', '2015-01-19 20:41:13', null, null);

-- ----------------------------
-- Table structure for b_mes_users
-- ----------------------------
DROP TABLE IF EXISTS `b_mes_users`;
CREATE TABLE `b_mes_users` (
  `USER_ID` varchar(20) NOT NULL,
  `PASSWORD` varchar(50) NOT NULL,
  `USER_NAME` varchar(20) DEFAULT NULL,
  `CREATEUSER` varchar(20) DEFAULT NULL,
  `CREATETIME` datetime DEFAULT NULL,
  `DEPT_ID` varchar(20) DEFAULT NULL,
  `EMAIL` varchar(50) DEFAULT NULL,
  `PHONE` varchar(20) DEFAULT NULL,
  `ENABLED` varchar(2) DEFAULT NULL,
  `UPDATEPSWTIME` datetime DEFAULT NULL,
  `DOMAIN` int(1) NOT NULL DEFAULT '0' COMMENT '域：1代表TRUE,0代表FALSE',
  `EMP_ID` varchar(20) DEFAULT NULL COMMENT '工号',
  `FACTORY_ID` varchar(10) NOT NULL DEFAULT '2100' COMMENT '工厂代码',
  PRIMARY KEY (`USER_ID`),
  UNIQUE KEY `EMP_ID` (`EMP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_mes_users
-- ----------------------------
INSERT INTO `b_mes_users` VALUES ('ccl', 'mnKZT3xVqKI=', 'ccl', 'zzk', '2015-01-19 16:29:27', '202', '', '', 'Y', '2015-05-21 16:14:05', '0', '43222d', '1100');
INSERT INTO `b_mes_users` VALUES ('chunliang.chen', 'mnKZT3xVqKI=', 'ccl', 'zzk', '2015-01-19 16:29:27', '202', '', '', 'Y', '2015-05-21 16:14:05', '1', '43222', '1100');
INSERT INTO `b_mes_users` VALUES ('junjie.yang', 'mnKZT3xVqKI=', '杨俊杰', 'hxl', '2015-03-19 16:34:07', '202', '', '', 'Y', '2015-07-09 09:32:57', '0', 'FX005506', '1100');
INSERT INTO `b_mes_users` VALUES ('kang.chen', 'mnKZT3xVqKI=', '陈康', 'weikang.song', '2015-12-14 13:20:51', '202', '', '', 'Y', null, '0', 'FX007451', '1100');
INSERT INTO `b_mes_users` VALUES ('quan.zhou', 'mnKZT3xVqKI=', '周泉', 'hxl', '2015-05-06 10:54:28', '202', 'quan.zhou@feixun.com.cn', '', 'Y', '2015-07-14 15:57:31', '0', 'ee3', '1100');
INSERT INTO `b_mes_users` VALUES ('weihua.lin', 'mnKZT3xVqKI=', '林威华', 'hxl', '2015-06-05 17:34:40', '202', '', '', 'Y', '2015-06-10 11:32:27', '1', 'FX005704', '1100');
INSERT INTO `b_mes_users` VALUES ('weikang.song', 'mnKZT3xVqKI=', '宋维康', 'yawei.cui', '2015-12-14 12:02:00', '202', '', '', 'Y', null, '0', 'FX007459', '1100');
INSERT INTO `b_mes_users` VALUES ('yawei.cui', 'mnKZT3xVqKI=', '崔亚伟', 'yawei.cui', '2015-01-19 16:29:27', '202', '', '', 'Y', null, '1', '9', '1100');
INSERT INTO `b_mes_users` VALUES ('yechun.ning', 'mnKZT3xVqKI=', '宁业春', 'FX007642', '2015-10-10 00:00:00', '202', 'yechun.ning@feixun.com', '', 'Y', '2015-10-10 16:30:31', '1', 'FX007642', '1100');
INSERT INTO `b_mes_users` VALUES ('zhibing.xie', 'mnKZT3xVqKI=', '谢志兵', 'zzk', '2015-07-30 13:36:36', '202', '', '', 'Y', '2015-10-10 10:27:50', '0', 'FX005516', '1100');

-- ----------------------------
-- Table structure for b_mes_user_group
-- ----------------------------
DROP TABLE IF EXISTS `b_mes_user_group`;
CREATE TABLE `b_mes_user_group` (
  `USER_ID` varchar(20) NOT NULL,
  `GROUP_ID` varchar(20) NOT NULL,
  `CREATETIME` datetime DEFAULT NULL,
  PRIMARY KEY (`USER_ID`,`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_mes_user_group
-- ----------------------------
INSERT INTO `b_mes_user_group` VALUES ('ccl', 'admin', '2015-06-02 09:28:34');
INSERT INTO `b_mes_user_group` VALUES ('chunliang.chen', 'admin', '2015-06-02 09:28:34');
INSERT INTO `b_mes_user_group` VALUES ('fengjuan.zheng', 'admin', '2015-04-15 15:25:50');
INSERT INTO `b_mes_user_group` VALUES ('jinjie.yang', 'admin', '2015-03-23 09:42:14');
INSERT INTO `b_mes_user_group` VALUES ('junjie.yang', 'admin', '2015-04-07 15:40:42');
INSERT INTO `b_mes_user_group` VALUES ('kang.chen', 'admin', '2015-09-06 10:35:45');
INSERT INTO `b_mes_user_group` VALUES ('lin02.wang', 'admin', '2015-09-06 11:04:54');
INSERT INTO `b_mes_user_group` VALUES ('ping.chen', 'admin', '2015-03-23 13:38:45');
INSERT INTO `b_mes_user_group` VALUES ('quan.zhou', 'admin', '2015-05-11 15:11:04');
INSERT INTO `b_mes_user_group` VALUES ('weihua.lin', 'admin', '2015-06-05 14:21:53');
INSERT INTO `b_mes_user_group` VALUES ('weikang.song', 'admin', '2015-09-06 10:28:03');
INSERT INTO `b_mes_user_group` VALUES ('yawei.cui', 'admin', '2015-01-19 16:37:56');
INSERT INTO `b_mes_user_group` VALUES ('yechun.ning', 'admin', '2015-10-12 15:24:44');
INSERT INTO `b_mes_user_group` VALUES ('zhibing.xie', 'admin', '2015-09-02 10:32:10');
INSERT INTO `b_mes_user_group` VALUES ('zhimin.yang', 'admin', '2015-08-25 15:40:44');

-- ----------------------------
-- Table structure for b_safeqty_setup
-- ----------------------------
DROP TABLE IF EXISTS `b_safeqty_setup`;
CREATE TABLE `b_safeqty_setup` (
  `ITEM_ID` varchar(40) NOT NULL,
  `ITEM_NAME` varchar(50) NOT NULL,
  `SPEC` varchar(20) NOT NULL,
  `DEPARTMENT` varchar(10) DEFAULT 'NA',
  `SAFE_QTY` decimal(10,0) DEFAULT NULL,
  `MUNIT` varchar(10) NOT NULL,
  `FACTORYID` varchar(10) NOT NULL,
  `CREATEUSER` varchar(30) DEFAULT NULL,
  `CREATETIME` datetime DEFAULT NULL,
  `UPDATEUSER` varchar(30) DEFAULT NULL,
  `UPDATETIME` datetime DEFAULT NULL,
  PRIMARY KEY (`ITEM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_safeqty_setup
-- ----------------------------
INSERT INTO `b_safeqty_setup` VALUES ('100006', '圆珠笔', '19', 'NA', '12', '支', '2100', 'yawei.cui', '2015-12-22 09:28:42', null, null);

-- ----------------------------
-- Table structure for b_sap_costcenter
-- ----------------------------
DROP TABLE IF EXISTS `b_sap_costcenter`;
CREATE TABLE `b_sap_costcenter` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `costcenter_id` varchar(30) DEFAULT NULL,
  `costcenter_name` varchar(30) DEFAULT NULL,
  `factory` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of b_sap_costcenter
-- ----------------------------
INSERT INTO `b_sap_costcenter` VALUES ('1', '2100110100', '总经理室', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('2', '2100120100', '财务部', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('3', '2100120200', '行政部', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('4', '2100120400', '人事部', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('5', '2100199999', '上海万得凯管理费用公共成本中心', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('6', '2100210030', '装配制造部-维修科-售后维修组', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('7', '2100340100', 'SMT制造部-SMT公共', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('8', '2100340101', 'SMT制造部-生产一科-SMT01', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('9', '2100340102', 'SMT制造部-生产一科-SMT02', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('10', '2100340103', 'SMT制造部-生产一科-SMT03', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('11', '2100340104', 'SMT制造部-生产一科-DIP', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('12', '2100340106', 'SMT制造部-生产一科-STEST', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('13', '2100340107', 'SMT制造部-生产一科-BURNIN', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('14', '2100340201', '装配制造部-生产一科-SASSY', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('15', '2100340301', '装配制造部-生产二科-MASSY', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('16', '2100340401', 'SMT制造部-治具加工科', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('17', '2100340501', 'SMT制造部-生产二科-MSMT01', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('18', '2100340502', 'SMT制造部-生产二科-MSMT02', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('19', '2100340503', 'SMT制造部-生产二科-MSMT03', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('20', '2100340504', 'SMT制造部-生产二科-MTEST', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('21', '2100350101', 'SMT制造部-生产一科', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('22', '2100350102', '装配制造部-生产一科', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('23', '2100350103', '装配制造部-生产二科', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('24', '2100350104', 'SMT制造部-治具加工科(间接)', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('25', '2100350105', 'SMT制造部-生产二科', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('26', '2100350106', 'SMT制造部-SMT线边科', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('27', '2100350107', 'SMT制造部-PCBA维修科', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('28', '2100350108', '装配制造部-维修科-装配维修组', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('29', '2100350109', '装配制造部-装配预加工科', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('30', '2100350201', '制造一部-线边科（冻结）', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('31', '2100350202', '产品技术部', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('32', '2100350203', '生产技术部', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('33', '2100350204', '生产品质管理部', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('34', '2100350205', '生产计划部', '2100');
INSERT INTO `b_sap_costcenter` VALUES ('35', '2100350206', '仓储物流部', '2100');

-- ----------------------------
-- Table structure for t_bk_allocation_record
-- ----------------------------
DROP TABLE IF EXISTS `t_bk_allocation_record`;
CREATE TABLE `t_bk_allocation_record` (
  `WHID` varchar(20) NOT NULL DEFAULT '',
  `PONAME` varchar(30) NOT NULL COMMENT '品名',
  `SPEC` varchar(30) NOT NULL COMMENT '规格',
  `QTY` int(11) NOT NULL DEFAULT '0' COMMENT '数量',
  `UNIT` varchar(20) DEFAULT NULL COMMENT '单位',
  `PRICE` decimal(20,2) NOT NULL COMMENT '单价',
  `FACTORYID` varchar(20) NOT NULL COMMENT '工厂代码',
  `PUTUSER` varchar(20) NOT NULL COMMENT '入库人',
  `PUTTIME` datetime NOT NULL COMMENT '入库时间',
  `OPSTATUS` int(2) DEFAULT NULL COMMENT '0：入库；1：归还',
  PRIMARY KEY (`WHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_bk_allocation_record
-- ----------------------------
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238528', '钢笔', '0.5mm', '1', '支', '2.00', '1100', 'ccl', '2015-12-17 10:23:59', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238529', '胶带', '0.5mm', '3', '卷', '0.50', '1100', 'ccl', '2015-12-17 10:24:07', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238530', '笔记本', '0.5mm', '3', '本', '0.50', '1100', 'ccl', '2015-12-17 10:24:07', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238535', '钢笔', '0.5mm', '1', '支', '2.00', '1100', 'ccl', '2015-12-18 10:53:28', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238536', '胶带', '0.5mm', '1', '卷', '0.50', '1100', 'ccl', '2015-12-18 10:53:28', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238537', '笔记本', '0.5mm', '1', '本', '0.50', '1100', 'ccl', '2015-12-18 10:53:28', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238538', '钢笔', '0.5mm', '1', '支', '2.00', '1100', 'ccl', '2015-12-18 10:53:59', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238539', '胶带', '0.5mm', '1', '卷', '0.50', '1100', 'ccl', '2015-12-18 10:53:59', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238540', '笔记本', '0.5mm', '1', '本', '0.50', '1100', 'ccl', '2015-12-18 10:54:00', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238542', '钢笔', '0.5mm', '1', '支', '2.00', '1100', 'ccl', '2015-12-18 10:57:59', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238543', '胶带', '0.5mm', '1', '卷', '0.50', '1100', 'ccl', '2015-12-18 10:57:59', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238544', '笔记本', '0.5mm', '1', '本', '0.50', '1100', 'ccl', '2015-12-18 10:57:59', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238545', '钢笔', '0.5mm', '1', '支', '2.00', '1100', 'ccl', '2015-12-18 10:58:15', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238546', '胶带', '0.5mm', '2', '卷', '0.50', '1100', 'ccl', '2015-12-18 10:58:15', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238547', '笔记本', '0.5mm', '3', '本', '0.50', '1100', 'ccl', '2015-12-18 10:58:15', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238556', '钢笔', '0.5mm', '1', '支', '2.00', '1100', 'ccl', '2015-12-18 11:08:47', '1');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238557', '胶带', '1m', '1', '卷', '0.50', '1100', 'ccl', '2015-12-18 11:08:47', '0');
INSERT INTO `t_bk_allocation_record` VALUES ('24332112681238558', '笔记本', '16k', '0', '本', '0.50', '1100', 'ccl', '2015-12-18 11:08:48', '0');

-- ----------------------------
-- Table structure for t_bk_inventory
-- ----------------------------
DROP TABLE IF EXISTS `t_bk_inventory`;
CREATE TABLE `t_bk_inventory` (
  `WHID` int(11) NOT NULL AUTO_INCREMENT,
  `PONAME` varchar(30) NOT NULL COMMENT '品名',
  `SPEC` varchar(30) NOT NULL COMMENT '规格',
  `QTY` int(11) NOT NULL DEFAULT '0' COMMENT '数量',
  `UNIT` varchar(20) DEFAULT NULL COMMENT '单位',
  `PRICE` decimal(20,2) NOT NULL COMMENT '单价',
  `FACTORYID` varchar(20) NOT NULL COMMENT '工厂代码',
  `PUTUSER` varchar(20) NOT NULL COMMENT '入库人',
  `PUTTIME` datetime NOT NULL COMMENT '入库时间',
  `WAERS` varchar(10) DEFAULT NULL COMMENT '货币',
  PRIMARY KEY (`WHID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_bk_inventory
-- ----------------------------
INSERT INTO `t_bk_inventory` VALUES ('1', '圆珠笔', '0.5mm', '3', '支', '2.00', '1100', 'ccl', '2015-12-18 10:57:59', null);
INSERT INTO `t_bk_inventory` VALUES ('2', '圆珠笔', '0.7mm', '3', '卷', '0.50', '2100', 'ccl', '2015-12-18 10:57:59', null);
INSERT INTO `t_bk_inventory` VALUES ('3', '胶带', '1m', '1', '卷', '0.50', '1100', 'ccl', '2015-12-18 11:08:47', null);
INSERT INTO `t_bk_inventory` VALUES ('4', '笔记本', '16k', '0', '本', '0.50', '1100', 'ccl', '2015-12-18 11:08:48', null);
INSERT INTO `t_bk_inventory` VALUES ('5', '静电衣黄色', 'M', '8', '件', '20.00', '2100', 'yawei.cui', '2015-12-22 09:46:04', null);
INSERT INTO `t_bk_inventory` VALUES ('6', '水杯', '白色', '8', '支', '10.00', '2100', 'yechun.ning', '2015-12-23 11:39:24', null);
INSERT INTO `t_bk_inventory` VALUES ('7', '签字笔', '0.7mm', '10', '支', '2.00', '2100', 'yechun.ning', '2015-12-23 12:00:06', null);
INSERT INTO `t_bk_inventory` VALUES ('8', '签字笔', '0.5mm', '10', '支', '2.00', '2100', 'yechun.ning', '2015-12-23 12:00:44', null);
INSERT INTO `t_bk_inventory` VALUES ('9', '白板', '200x100', '1', '块', '100.00', '2100', 'yechun.ning', '2015-12-23 12:02:22', null);
INSERT INTO `t_bk_inventory` VALUES ('10', '插线板', '7口', '20', '块', '20.00', '2100', 'yechun.ning', '2015-12-23 12:03:37', null);
INSERT INTO `t_bk_inventory` VALUES ('11', '档案袋', '黄色', '20', '个', '1.00', '2100', 'yechun.ning', '2015-12-23 12:04:37', null);
INSERT INTO `t_bk_inventory` VALUES ('12', '圆珠笔', '0.7mm', '3', '支', '2.00', '1100', 'ccl', '2015-12-18 10:57:59', '');

-- ----------------------------
-- Table structure for t_consumables_request
-- ----------------------------
DROP TABLE IF EXISTS `t_consumables_request`;
CREATE TABLE `t_consumables_request` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `applyUserName` varchar(20) NOT NULL,
  `applyUserId` varchar(20) NOT NULL,
  `applyDeptCode` varchar(20) NOT NULL,
  `applyDeptName` varchar(100) NOT NULL,
  `createDate` date NOT NULL,
  `totalAmount` float(11,2) DEFAULT NULL,
  `leaderOpinion` varchar(200) DEFAULT NULL,
  `adminDeptOpinion` varchar(200) DEFAULT NULL,
  `warehouseOpinion` varchar(200) DEFAULT NULL,
  `status` varchar(1) NOT NULL COMMENT '审核状态 0.底稿中 1.请审中 2.已审核 3.被驳回',
  `factoryId` varchar(20) NOT NULL,
  `IsAllDone` varchar(1) NOT NULL COMMENT '是否都完成了 Y.已都完成 N.未完成',
  `applyUserEmpId` varchar(10) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_consumables_request
-- ----------------------------
INSERT INTO `t_consumables_request` VALUES ('1', '1', '1', '1', '1', '1', '2015-12-16', '1.00', '1', '1', '1', 'Y', '2100', 'N', '');
INSERT INTO `t_consumables_request` VALUES ('3', 'LY201512250003', '宁业春', 'yechun.ning', '202', '制造执行系统部', '2015-12-25', null, null, null, null, '0', '1100', 'N', 'FX007642');

-- ----------------------------
-- Table structure for t_consumables_request_detail
-- ----------------------------
DROP TABLE IF EXISTS `t_consumables_request_detail`;
CREATE TABLE `t_consumables_request_detail` (
  `drid` int(11) NOT NULL AUTO_INCREMENT,
  `sn` int(11) NOT NULL,
  `categoryOne` varchar(20) DEFAULT NULL,
  `name` varchar(20) NOT NULL,
  `standard` varchar(10) DEFAULT NULL,
  `unit` varchar(20) NOT NULL,
  `requiredQty` int(11) NOT NULL,
  `actualQty` int(11) NOT NULL DEFAULT '0' COMMENT '已领数量',
  `price` float(11,2) DEFAULT NULL,
  `amount` float(11,2) DEFAULT NULL,
  `url` varchar(100) DEFAULT NULL,
  `rid` int(11) NOT NULL,
  `dStatus` varchar(1) NOT NULL,
  `signUserName` varchar(20) DEFAULT NULL,
  `signUserId` varchar(20) DEFAULT NULL,
  `signDeptCode` varchar(20) DEFAULT NULL,
  `signDeptName` varchar(20) DEFAULT NULL,
  `signDate` datetime DEFAULT NULL,
  `costCenter` varchar(20) NOT NULL,
  `actualUser` varchar(20) NOT NULL DEFAULT '实际使用人',
  `actualDeptCode` varchar(20) NOT NULL COMMENT '实际使用人所在部门',
  `categoryTwo` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`drid`,`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_consumables_request_detail
-- ----------------------------
INSERT INTO `t_consumables_request_detail` VALUES ('1', '1', '1', '静电衣黄色', 'XL', '1', '1', '0', '1.00', '1.00', null, '1', 'N', '张三', null, null, null, '2015-12-23 11:10:31', '测试产线1', '实际使用人', '113', null);
INSERT INTO `t_consumables_request_detail` VALUES ('2', '2', '2', '静电衣黄色', 'M', '1', '2', '0', '2.00', '4.00', null, '1', 'N', '顶顶顶顶', null, null, null, '2015-12-23 11:33:00', '测试产线1', '实际使用人', '113', null);
INSERT INTO `t_consumables_request_detail` VALUES ('3', '0', '办公用品5', '圆珠笔', '18', '支', '11', '0', null, null, null, '3', 'N', null, null, null, null, null, '111', '宋维康', '制造执行系统部', '笔');

-- ----------------------------
-- Table structure for t_dept_allocation_record
-- ----------------------------
DROP TABLE IF EXISTS `t_dept_allocation_record`;
CREATE TABLE `t_dept_allocation_record` (
  `WHID` varchar(20) NOT NULL DEFAULT '',
  `PONAME` varchar(30) NOT NULL COMMENT '品名',
  `SPEC` varchar(30) NOT NULL COMMENT '规格',
  `QTY` int(11) NOT NULL DEFAULT '0' COMMENT '数量',
  `UNIT` varchar(20) DEFAULT NULL COMMENT '单位',
  `PRICE` decimal(20,2) NOT NULL COMMENT '单价',
  `FACTORYID` varchar(20) NOT NULL COMMENT '工厂代码',
  `PUTUSER` varchar(20) NOT NULL COMMENT '入库人',
  `PUTTIME` datetime NOT NULL COMMENT '入库时间',
  `DEPART` varchar(30) NOT NULL COMMENT '部门',
  `OPSTATUS` int(2) NOT NULL COMMENT '操作状态	0：分配；1：归还 2.领用',
  PRIMARY KEY (`WHID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_dept_allocation_record
-- ----------------------------
INSERT INTO `t_dept_allocation_record` VALUES ('24332112681238560', 'rr', 'rr', '22', '2', '2.00', '2', '2', '2015-12-22 09:22:17', '2', '2');
INSERT INTO `t_dept_allocation_record` VALUES ('24332112681238578', '静电衣黄色', 'L', '1', '1', '2.00', '1100', 'kang.chen', '2015-12-22 13:28:23', '113', '2');

-- ----------------------------
-- Table structure for t_dept_inventory
-- ----------------------------
DROP TABLE IF EXISTS `t_dept_inventory`;
CREATE TABLE `t_dept_inventory` (
  `WHID` int(11) NOT NULL AUTO_INCREMENT,
  `PONAME` varchar(30) NOT NULL COMMENT '品名',
  `SPEC` varchar(30) NOT NULL COMMENT '规格',
  `QTY` int(11) NOT NULL DEFAULT '0' COMMENT '数量',
  `UNIT` varchar(20) DEFAULT NULL COMMENT '单位',
  `PRICE` decimal(20,2) NOT NULL COMMENT '单价',
  `FACTORYID` varchar(20) NOT NULL COMMENT '工厂代码',
  `PUTUSER` varchar(20) NOT NULL COMMENT '入库人',
  `PUTTIME` datetime NOT NULL COMMENT '入库时间',
  `DEPART` varchar(30) NOT NULL COMMENT '部门',
  PRIMARY KEY (`WHID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_dept_inventory
-- ----------------------------
INSERT INTO `t_dept_inventory` VALUES ('1', '静电衣黄色', 'XL', '2', '件', '1.00', '2100', 'yechun.ning', '2015-12-21 10:21:24', '113');
INSERT INTO `t_dept_inventory` VALUES ('2', '静电衣黄色', 'M', '0', '件', '2.00', '2100', 'yechun.ning', '2015-12-21 00:00:00', '113');
INSERT INTO `t_dept_inventory` VALUES ('3', '圆珠笔', '0.7mm', '5', '支', '2.00', '2100', 'yawei.cui', '2015-12-21 15:11:57', '113');

-- ----------------------------
-- Table structure for t_inventory_out_record
-- ----------------------------
DROP TABLE IF EXISTS `t_inventory_out_record`;
CREATE TABLE `t_inventory_out_record` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `request_code` varchar(20) NOT NULL,
  `request_sn` int(11) NOT NULL,
  `consumables_category` varchar(20) NOT NULL,
  `consumables_name` varchar(20) NOT NULL,
  `spec` varchar(20) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `sign_user_name` varchar(20) NOT NULL,
  `out_qty` int(11) NOT NULL,
  `out_user` varchar(20) NOT NULL,
  `out_time` datetime NOT NULL,
  `inventory_old_qty` int(20) NOT NULL,
  `inventory_new_qty` int(20) NOT NULL,
  `factory_id` varchar(20) NOT NULL,
  `cost_center` varchar(20) NOT NULL,
  `actual_user` varchar(20) NOT NULL,
  `actual_dept_code` varchar(20) NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_inventory_out_record
-- ----------------------------

-- ----------------------------
-- Table structure for t_inventory_po
-- ----------------------------
DROP TABLE IF EXISTS `t_inventory_po`;
CREATE TABLE `t_inventory_po` (
  `POID` varchar(20) NOT NULL DEFAULT '',
  `PONO` varchar(20) NOT NULL COMMENT '采购订单号',
  `PONAME` varchar(30) NOT NULL COMMENT '品名',
  `SPEC` varchar(30) NOT NULL COMMENT '规格',
  `QTY` int(11) NOT NULL DEFAULT '0' COMMENT '数量',
  `INQTY` int(11) NOT NULL DEFAULT '0' COMMENT '入库数量',
  `UNIT` varchar(20) NOT NULL COMMENT '单位',
  `PRICE` decimal(20,2) NOT NULL COMMENT '单价',
  `STOCKSTATUS` int(2) NOT NULL DEFAULT '0' COMMENT '入库状态	0：待入库，1：入库',
  `POSTATUS` int(2) NOT NULL DEFAULT '1' COMMENT '订单状态	0：取消，默认为：1',
  `FACTORYID` varchar(20) NOT NULL COMMENT '工厂代码',
  `PUTUSER` varchar(20) DEFAULT NULL COMMENT '入库人',
  `PUTTIME` datetime DEFAULT NULL COMMENT '入库时间',
  `OPER` varchar(20) DEFAULT NULL COMMENT '操作者',
  `OPERTIME` datetime DEFAULT NULL COMMENT '操作时间',
  `EBELP` varchar(10) DEFAULT NULL COMMENT '采购凭证的项目编号',
  `REMARK` varchar(50) DEFAULT NULL COMMENT '备注',
  `MEINS` varchar(10) DEFAULT NULL COMMENT '采购订单的计量单位',
  `WAERS` varchar(10) DEFAULT NULL COMMENT '货币',
  PRIMARY KEY (`POID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_inventory_po
-- ----------------------------
INSERT INTO `t_inventory_po` VALUES ('24332112681238532', 'po001', '钢笔', '0.5mm', '98', '0', '支', '2.00', '0', '1', '1100', 'ccl', '2015-12-18 10:58:14', 'ccl', '2015-12-18 10:58:14', null, null, null, null);
INSERT INTO `t_inventory_po` VALUES ('24332112681238533', 'po001', '胶带', '0.5mm', '97', '0', '卷', '0.50', '0', '1', '1100', 'ccl', '2015-12-18 10:58:14', 'ccl', '2015-12-18 10:58:14', null, null, null, null);
INSERT INTO `t_inventory_po` VALUES ('24332112681238534', 'po001', '笔记本', '0.5mm', '96', '0', '本', '0.50', '0', '1', '1100', 'ccl', '2015-12-18 10:58:14', 'ccl', '2015-12-18 10:58:14', null, null, null, null);
INSERT INTO `t_inventory_po` VALUES ('24332112681238541', 'po001', '笔记本', '0.5mm', '100', '0', '本', '0.50', '0', '1', '2100', 'ccl', '2015-12-18 10:53:59', 'ccl', '2015-12-18 10:53:59', null, null, null, null);
INSERT INTO `t_inventory_po` VALUES ('24332112681238552', 'po002', '钢笔', '0.5mm', '97', '0', '支', '2.00', '0', '1', '1100', 'ccl', '2015-12-18 11:08:47', 'ccl', '2015-12-18 11:08:47', null, null, null, null);
INSERT INTO `t_inventory_po` VALUES ('24332112681238553', 'po002', '胶带', '1m', '96', '0', '卷', '0.50', '0', '1', '1100', 'ccl', '2015-12-18 11:08:47', 'ccl', '2015-12-18 11:08:47', null, null, null, null);
INSERT INTO `t_inventory_po` VALUES ('24332112681238554', 'po002', '笔记本', '16k', '96', '0', '本', '0.50', '0', '1', '1100', 'ccl', '2015-12-18 11:08:47', 'ccl', '2015-12-18 11:08:47', null, null, null, null);
INSERT INTO `t_inventory_po` VALUES ('24332112681238555', 'po002', '笔记本', '32k', '100', '0', '本', '0.50', '0', '1', '2100', 'ccl', '2015-12-18 10:53:59', 'ccl', '2015-12-18 10:53:59', null, null, null, null);
INSERT INTO `t_inventory_po` VALUES ('24342667580145669', 'po005', '键盘1', '希捷', '200', '0', '个', '5.50', '0', '1', '1100', '录入人', '2015-12-25 10:17:42', '操作人', '2015-12-25 10:17:42', '', 'test', '', 'RMB');
INSERT INTO `t_inventory_po` VALUES ('24342667580145670', 'po005', '键盘2', '希捷', '400', '0', '个', '5.50', '0', '1', '1100', '录入人', '2015-12-25 10:17:42', '操作人', '2015-12-25 10:17:42', '', 'test', '', 'RMB');
INSERT INTO `t_inventory_po` VALUES ('24342667580145671', 'po005', '键盘3', '希捷', '600', '0', '个', '5.50', '0', '1', '1100', '录入人', '2015-12-25 10:17:42', '操作人', '2015-12-25 10:17:42', '', 'test', '', 'RMB');
INSERT INTO `t_inventory_po` VALUES ('24342667580145672', 'po005', '键盘4', '希捷', '2000', '0', '个', '5.50', '0', '0', '1100', '录入人', '2015-12-25 10:17:42', '操作人', '2015-12-25 10:17:42', '', 'test', '', 'RMB');
INSERT INTO `t_inventory_po` VALUES ('24342667580145673', 'po005', '键盘5', '希捷', '2500', '0', '个', '5.50', '0', '0', '1100', '录入人', '2015-12-25 10:17:42', '操作人', '2015-12-25 10:17:42', '', 'test', '', 'RMB');
DROP TRIGGER IF EXISTS `default_WHID`;
DELIMITER ;;
CREATE TRIGGER `default_WHID` BEFORE INSERT ON `t_bk_allocation_record` FOR EACH ROW if (new.WHID='' or new.WHID is null) then  
set new.WHID= uuid_short();  
end if
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `default_dept_WHID`;
DELIMITER ;;
CREATE TRIGGER `default_dept_WHID` BEFORE INSERT ON `t_dept_allocation_record` FOR EACH ROW if (new.WHID='' or new.WHID is null) then  
set new.WHID= uuid_short();  
end if
;;
DELIMITER ;
DROP TRIGGER IF EXISTS `default_POID`;
DELIMITER ;;
CREATE TRIGGER `default_POID` BEFORE INSERT ON `t_inventory_po` FOR EACH ROW if (new.POID='' or new.POID is null) then  
set new.POID = uuid_short();  
end if
;;
DELIMITER ;
